Welcome to itucsdb1942's documentation!
=======================================

:Team: TRACE

:Members:

   * Mürüvvet BOZKURT
   * Neslihan ÇEKİÇ

**TRACE is follow-up application that you can keep track of the watching and reading status of TV series and book. It contains user-specific lists.**

.. figure:: textlogo.jpg
	:scale: 30 %
	:alt: Logo
	:align: center

App: http://itucsdb1942.herokuapp.com/

Github Page: https://github.com/itucsdb1942/itucsdb1942

Contents:

.. toctree::
   :maxdepth: 3

   user/index
   developer/index
   
      
   
